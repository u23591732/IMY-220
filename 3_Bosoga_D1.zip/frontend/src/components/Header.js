import React from 'react';


export class Header extends React.Component{

    constructor(props)
    {
        super(props);

    }
    render()
    {
        return(
            <div style={{backgroundColor:'#24392F', overflow: 'hidden',padding: '20px 10px', display: 'flex',alignItems: 'center',justifyContent: 'start',gap: '30px'}} >

                <img style={{height:'50px',width : '100px',paddingRight:'30px',borderStyle:'none'}} src='./assets/images/loop.png'></img>
                <img style={{height:'40px',width : '100px',paddingRight:'30px',borderStyle:'none'}} src='./assets/images/s.png'></img>
                <img style={{height:'40px',width : '100px',paddingRight:'30px',borderStyle:'none'}} src='./assets/images/p.png'></img>
                <img style={{height:'40px',width : '100px',paddingRight:'30px',borderStyle:'none'}} src='./assets/images/h.png'></img>
                <img style={{height:'40px',width : '100px',paddingRight:'30px',borderStyle:'none'}} src='./assets/images/l.png'></img>
                
            </div>
        )
    }
}