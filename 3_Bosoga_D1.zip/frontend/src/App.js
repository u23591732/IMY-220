import React from "react";
import { ShortList } from "./pages/ShortList";
import { ProfileList } from "./pages/ProfileList";
import { Header } from "./components/Header";
import { PlaylistShort} from "./components/PlaylistShort";
import { ProfileShort} from "./components/ProfileShort";
import {SignUp} from "./components/SignUp";

import { Home } from "./pages/Home";
import { Search } from "./components/Search";
import { Login } from "./components/Login";
import { Profile } from "./pages/Profile";
import { PlaylistPage} from "./pages/PlaylistPage";
import { EditProfile } from "./pages/editProfile";

export class App extends React.Component{


    constructor(props)
    {
        super(props);
        
    }


    render()
    {
        /* <Profile profilePic = "./assets/images/kendra.jpg" fullName="Joyce Tshabalala" userName="jtshanbalal63"
            pronouns="She/Her" bio="23 year old music journalist with a passion for old school hip-hop and rnb & shit , so send a friend request if you know some good throwbacks!"
            insta = "j@oycehearts90s" ex ="@joyce63hearts90s" tik="None"/>  
        */
   
            /*<EditProfile profilePic = "./assets/images/kendra.jpg" fullName="Joyce Tshabalala" userName="jtshanbalal63"
            pronouns="She/Her" bio="23 year old music journalist with a passion for old school hip-hop and rnb & shit , so send a friend request if you know some good throwbacks!"
            insta = "@joycehearts90s" ex ="@joyce63hearts90s" tik="None"/>
             */


        
         return(
            <React.Fragment>
                <Header/>
            
    <PlaylistPage playPic = './assets/images/group.jpg' playBio = 'A mix of southern-inspired hiphop bangers and bass boosted club anthems'
    playNo='#004' playUser='Phil Jones' playGenre='Hip-hop' playTags = '#southern #bassboosted #hiphop'/>

            
            </React.Fragment>

         )
    }





}