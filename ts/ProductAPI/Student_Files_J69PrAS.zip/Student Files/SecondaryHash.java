public class SecondaryHash extends HashFunctions {

    public SecondaryHash() {
    }


    public int hash(String input) {
        
    }
}