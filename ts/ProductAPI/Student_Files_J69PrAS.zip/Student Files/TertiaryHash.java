public class TertiaryHash extends HashFunctions {
    private int divisor;

    public TertiaryHash(int divisor) {
       
    }

    public int hash(String input) {
      
    }
  
}