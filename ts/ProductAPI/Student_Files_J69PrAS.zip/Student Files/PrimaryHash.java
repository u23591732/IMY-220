public class PrimaryHash extends HashFunctions {
    public PrimaryHash() {
    }

    public int hash(String input) {
       
    }
}