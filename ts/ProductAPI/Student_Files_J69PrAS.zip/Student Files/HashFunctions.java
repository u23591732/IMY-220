public abstract class HashFunctions {
    public abstract int hash(String input);
    
}
