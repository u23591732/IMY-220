﻿using Microsoft.AspNetCore.Identity;

namespace ApplicationSecurity_Backend.Models
{
    public class AppUser: IdentityUser
    {
    }
}
